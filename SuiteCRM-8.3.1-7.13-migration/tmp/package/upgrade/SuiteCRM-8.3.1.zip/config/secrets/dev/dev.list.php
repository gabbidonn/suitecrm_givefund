<?php

return array (
  'APP_SECRET' => NULL,
  'DATABASE_URL' => NULL,
);
