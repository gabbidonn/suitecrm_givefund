# SuiteCRM common

This library was generated with [Angular CLI](https://github.com/angular/angular-cli) version 11.0.0.


## Build

Run `yarn build:common` to build the project. The build artifacts will be stored in the `dist/` directory.
