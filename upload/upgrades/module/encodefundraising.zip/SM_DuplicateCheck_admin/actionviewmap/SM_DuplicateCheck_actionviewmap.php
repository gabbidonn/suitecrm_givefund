<?php

$action_view_map['settings'] = 'settings';
