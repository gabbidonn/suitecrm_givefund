<?php

$mod_strings['LBL_SUITEDUPLICATECHECK'] = 'Duplicate Check';
$mod_strings['LBL_SUITEDUPLICATECHECK_TITLE'] = 'Duplicate Check Settings';
$mod_strings['LBL_SUITEDUPLICATECHECK_DESCRIPTION'] = 'Map the fields for which you want to find duplicates.';
