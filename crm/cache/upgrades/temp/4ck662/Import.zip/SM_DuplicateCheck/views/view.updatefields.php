<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('include/MVC/View/views/view.ajax.php');
class SM_DuplicateCheckViewUpdateFields extends ViewAjax
{
   	public function __construct()
        {
                parent::__construct();
        }
        public function display(){
           extract($_POST);
         
        	global $db;
           
            
            $isenabled=$_POST['isenabled'];
	    $crosscheck=$_POST['ischecked'];
            	if($isenabled == ""){
        	   	 $isenabled = 0;
           	}
		if($ischecked == "")
			$crosscheck = 0;
		else
			$crosscheck = 1;
        	$fieldID=$_POST['fieldID'];
            $modulename=$_POST['modulename'];
            $fieldsID = implode(',', $fieldID);
        	if(empty($modulename) || trim($modulename) == ''){
                header("location:index.php?module=SM_DuplicateCheck&view=settings&sourceModule=$modulename");
        		die('Failure');
                
        	}
            if($modulename != ""){
        	$runQuery = $db->pquery("UPDATE sm_duplicatechecksettings SET fieldstomatch='$fieldsID' ,isenabled='$isenabled' ,crosscheck='$crosscheck' WHERE modulename='$modulename'", array());
            header("location:index.php?module=SM_DuplicateCheck&action=settings&sourceModule=$modulename&notify=1");
        }
				if($result){
					echo $result;die;
				}
        	die('Failure');

        }
    }

?>
