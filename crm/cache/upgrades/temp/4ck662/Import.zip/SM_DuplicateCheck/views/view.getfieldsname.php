<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('include/MVC/View/views/view.ajax.php');
class SM_DuplicateCheckViewGetFieldsName extends ViewAjax
{
    public function __construct()   {
        parent::__construct();
        $this->response['result'] = null;
    }

	public function display()   {
		global $db;
		$arrayValues = array();
		extract($_GET);
		$modulename = $_GET['moduleName'];
		$runQuery = $db->pquery("SELECT fieldstomatch FROM sm_duplicatechecksettings WHERE modulename='$modulename' AND isenabled='1'", array());
		$fetchValues = $db->fetchByAssoc($runQuery);
		$count = $db->getRowCount($runQuery);
		$explodedValues = explode(",",$fetchValues['fieldstomatch']);
		array_push($arrayValues,count($explodedValues));
		foreach ($explodedValues as $key => $value) {
			array_push($arrayValues,$value);
		}
		$result = array($count, $arrayValues);
		$this->response['result'] = $result;
		echo json_encode($this->response);

	}
}


