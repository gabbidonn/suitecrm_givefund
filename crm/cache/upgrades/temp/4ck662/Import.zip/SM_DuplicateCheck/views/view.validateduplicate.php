<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('include/MVC/View/views/view.ajax.php');
class SM_DuplicateCheckViewValidateDuplicate extends ViewAjax
{
    public function __construct()   {
        parent::__construct();
        $this->response['result'] = null;
    }

    public function display()   {
        global $db;     
        $arrayValues = array();
        $arrayQuery = "";
        $arrayQuery1="";
        $recordDetails = array();
        $fieldlabelQuery = "";
        $countoffieldNames=array();
        $crossfieldname=array();
        $crosstablename=array();
        $crosscheckDetails=array();
        $fetchcrosscount=0;
        $record_view = $_REQUEST['record_view'];
        $record_id = $_REQUEST['record_id'];

        extract($_GET);
        $modulename = $_GET['moduleName'];
        $fieldName = $_GET['fieldName'];
        $fieldValues = $_GET['fieldValues'];
        $fieldType = $_GET['fieldtype'];
        $tabid=$fetchResult['tabid'];
        $fields = explode(",",$columnname);
        $countoffields = count($fields);
        array_push($countoffieldNames,$countoffields);
        array_push($countoffieldNames,$fields);

        unset($tab_info[$masterTableName]);
      
        $arrayQuery .= "SELECT $fieldName,";
        $crosscheckfields = array('phone_work', 'phone_office', 'phone_home', 'phone_mobile', 'phone_other');
        $module_table = array('Contacts' => 'contacts', 'Leads' => 'leads', 'Accounts' => 'accounts', 'Cases' => 'cases', 'Prospects' => 'prospects');
        $tablename = $module_table[$modulename];
        $tablename_cstm = $tablename.'_cstm';
        if($moduleName == 'Leads' || $moduleName == 'Contacts' || $moduleName == 'Prospects'){
            $arrayQuery .= "id as recordid, first_name, last_name from $tablename";
        }
        else{
            $arrayQuery .= "id as recordid, name from $tablename";
        }
        $conditionQuery =  " WHERE $fieldName = '$fieldValues' AND deleted = '0'";

        $arrayQuery .= $conditionQuery;  
        $arrayQuery1 = "SELECT * from ".'  '.$tablename_cstm.' '." WHERE $fieldName = '$fieldValues'"; // for custom module..
       
        
        $selmodule = $moduleName;
        if($selmodule == 'Contacts')    {
            $moduleName = 'Contacts';
            $trimmed_selmodule = substr($selmodule, 0, -1);
        }
        elseif($selmodule == 'Leads')    {
            $moduleName = 'Leads';
            $trimmed_selmodule = substr($selmodule, 0, -1);
        }
        elseif($selmodule == 'Accounts')    {
            $moduleName = 'Accounts';
            $trimmed_selmodule = substr($selmodule, 0, -1);
        }
        elseif($selmodule == 'Cases'){
            $moduleName = 'Cases';
            $trimmed_selmodule = substr($selmodule, 0, -1);
        }
        elseif($selmodule == 'Prospects'){
            $moduleName = 'Prospects';
            $trimmed_selmodule = substr($selmodule, 0, -1);
        }

        // module translation starts here
        if(empty($_SESSION['authenticated_user_language']))
            $current_language = $sugar_config['default_language'];
        else
            $current_language = $_SESSION['authenticated_user_language'];

        $languageFileLocation = "modules/{$moduleName}/language/{$current_language}.lang.php";
        if(file_exists($languageFileLocation))  {
            require_once("modules/{$moduleName}/language/{$current_language}.lang.php");
        }

        // module translation ends here

        // requiring module class file to get field names
        require_once("modules/{$moduleName}/{$trimmed_selmodule}.php");
        if($moduleName == 'Cases')
            $trimmed_selmodule = 'aCase';

        $focus = new $trimmed_selmodule();
       

        // getting selected module fields
        $moduleFields  = $focus->field_name_map;
        foreach($moduleFields as $key => $value) {
            $fieldLabel = $value['vname'];
            if(isset($mod_strings[$value['vname']]) || !empty($mod_strings[$value['vname']]))
                $fieldLabel = $mod_strings[$value['vname']];
               
            $fieldLabel = explode(':', $fieldLabel);
            
            if($value['name'] == $fieldName)
                $fetchFieldLabelQuery['fieldlabel'] = $fieldLabel[0];
        }
        
        $crosscheckvalue = $db->getOne("SELECT crosscheck FROM sm_duplicatechecksettings WHERE modulename='$moduleName' AND isenabled='1'");
        
        if($fieldType == 'email' && $crosscheckvalue == 0){
            $arrayQuery = "SELECT a.email_address,a.id as email_recordid, b.bean_id as recordid,b.bean_module from email_addresses a, email_addr_bean_rel b WHERE a.email_address = '$fieldValues' AND a.deleted = '0' AND  a.id = b.email_address_id";
            $fetchFieldLabelQuery['fieldlabel'] = 'Email Address';
        }
        elseif(in_array($fieldName, $crosscheckfields) && $crosscheckvalue == 1)
            $arrayQuery = '';
        $runQuery = $db->pquery($arrayQuery, array());
        
         $runQuery1 = $db->pquery($arrayQuery1, array());
         
         $count = $db->getRowCount($runQuery);
        $count1 = $db->getRowCount($runQuery1);
        
         if(!empty($count1)){ 
         array_push($recordDetails,$count1);// for custom field
         }else{
        array_push($recordDetails,$count);
        }
        array_push($recordDetails, $fetchFieldLabelQuery);
        array_push($recordDetails,$countoffieldNames);
        
        $fetchResultContent = array();
         $fetchResultContent1 = array();
         while ($fetchResultContent1 = $db->fetchByAssoc($runQuery1)) { // for custom field
         
            
            $recordId = current($fetchResultContent1);//['recordid'];
            $primary_fieldname = array_search($recordId, $fetchResultContent1, false);

            $getName = $db->pquery("select $fieldName from $tablename_cstm where $primary_fieldname = '$recordId'");
                        $row = $db->fetchByAssoc($getName);
                        $fetchResultContent1['recordid'] = $recordId;
                        //$fetchResultContent1[$fieldName] = $row[$fieldName];
                        $fetchResultContent1['name'] = $row[$fieldName];
                array_push($recordDetails, $fetchResultContent1);
}




        while ($fetchResultContent = $db->fetchByAssoc($runQuery)) {
            if($fieldType == 'email'){
                if($fetchResultContent['bean_module'] == $moduleName){
                    $recordId = $fetchResultContent['recordid'];
                    if($moduleName == 'Accounts'){
                        $getName = $db->pquery("select name from $tablename where id = '$recordId'");
                        $row = $db->fetchByAssoc($getName);
                        $fetchResultContent['name'] = $row['name'];
                        array_push($recordDetails, $fetchResultContent);
                        
                    }
                    else{
                        $getName = $db->pquery("select first_name, last_name from $tablename where id = '$recordId'");
                        $row = $db->fetchByAssoc($getName);
                        $fetchResultContent['first_name'] = $row['first_name'];
                        $fetchResultContent['last_name'] = $row['last_name'];
                        array_push($recordDetails, $fetchResultContent);
                    }
                }
            }
            else
                array_push($recordDetails, $fetchResultContent);
        }
        
        if($crosscheckvalue == 1){
            if($fieldType == 'email' || $fieldName == 'phone_mobile' || $fieldName == 'phone_work' || $fieldName == 'phone_office' || $fieldName == 'phone_home')
            {
                if($fieldType == 'email'){
                    $arrayQuery = "SELECT a.email_address,a.id as email_recordid, b.bean_id as recordid, b.bean_module as modulename from email_addresses a, email_addr_bean_rel b WHERE a.email_address = '$fieldValues' AND a.deleted = '0' AND  a.id = b.email_address_id";
                    $fetchFieldLabelQuery['fieldlabel'] = 'Email Address';
                    $runQuery = $db->pquery($arrayQuery, array());

                    $count = $db->getRowCount($runQuery);


                    array_push($crosscheckDetails, '');
                    array_push($crosscheckDetails,$count);
                    array_push($crosscheckDetails,$count);
                    $fetchcrossQuery=array();
                    while ($fetchcrosscheckvalQuery = $db->fetchByAssoc($runQuery)) {
                        $recordId = $fetchcrosscheckvalQuery['recordid'];
                        if($fetchcrosscheckvalQuery['modulename'] == 'Accounts'){
                            $getName = $db->pquery("select name from accounts where id = '$recordId'");
                            $row = $db->fetchByAssoc($getName);
                            $fetchcrosscheckvalQuery['name'] = $row['name'];
                            array_push($fetchcrossQuery,$fetchcrosscheckvalQuery);
                        }
                        else{
                            $gettablename = array('Leads' => 'leads', 'Contacts' => 'contacts');
                            $tablename = $gettablename[$fetchcrosscheckvalQuery['modulename']];
                            $getName = $db->pquery("select first_name, last_name from $tablename where id = '$recordId'");
                            $row = $db->fetchByAssoc($getName);
                            $fetchcrosscheckvalQuery['first_name'] = $row['first_name'];
                            $fetchcrosscheckvalQuery['last_name'] = $row['last_name'];
                            array_push($fetchcrossQuery,$fetchcrosscheckvalQuery);
                            
                        }

                    }
                    array_push($crosscheckDetails, $fetchcrossQuery);
                }
                elseif($fieldName == 'phone_work' || $fieldName == 'phone_office' || $fieldName == 'phone_home' || $fieldName == 'phone_mobile'){

                    $fetchcrossQuery=array();
                    $modules = array('Leads' => 'leads', 'Contacts' => 'contacts', 'Accounts' => 'accounts');
                    foreach($modules as $key => $singletable){
                        $crossmodule = $key;
                        if($singletable == 'accounts')
                            $getmoduleValue = $db->pquery("select id as recordid ,name from $singletable where phone_office  = '$fieldValues' and deleted = '0'", array());
                        else
                            $getmoduleValue = $db->pquery("select id as recordid , first_name,last_name from $singletable where phone_home = '$fieldValues' or phone_mobile = '$fieldValues' or phone_work  = '$fieldValues' or phone_other = '$fieldValues' and deleted = '0'", array());
                        while ($fetchcrosscheckvalQuery = $db->fetchByAssoc($getmoduleValue)) {
                            if($fetchcrosscheckvalQuery){
                                $fetchcrosscheckvalQuery['modulename'] = $crossmodule;
                                array_push($fetchcrossQuery,$fetchcrosscheckvalQuery);
                            }
                        }
                    }
                    $count = count($fetchcrossQuery);   
                    array_push($crosscheckDetails, '');
                    array_push($crosscheckDetails,$count);
                    array_push($crosscheckDetails,$count);
                    array_push($crosscheckDetails, $fetchcrossQuery);
                }
            }
        }


        $this->response['result'] = array($recordDetails, $crosscheckDetails);
        echo json_encode($this->response);
        die;
    }
}

