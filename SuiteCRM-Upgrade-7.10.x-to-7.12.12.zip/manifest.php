<?php
$manifest = [
    'name' => 'SuiteCRM',
    'author' => 'SalesAgility',
    'type' => 'patch',
    'published_date' => '2023-06-30 12:00:00',
    'version' => '7.12.12',
    'is_uninstallable' => false,

    'acceptable_suitecrm_versions' =>
        [
            'regex_matches' =>
                [
                    '^7.10(-*)',
                    '^7.10(.*)'
                ],
        ],

    'acceptable_php_versions' =>
        [
            'regex_matches' =>
                [
                    '^7.3(.*)', '^7.4(.*)', '^8.0(.*)', '^8.1(.*)'
                ],
        ],

    'copy_files' =>
        [
            'from_dir' => 'SuiteCRM-Upgrade-7.10.x-to-7.12.12',
            'to_dir' => '',
        ],
];
