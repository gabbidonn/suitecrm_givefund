<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version = '7.12.12';
$suitecrm_timestamp = '2023-07-11 12:00:00';
